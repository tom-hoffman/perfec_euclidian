# sets the name of the Circuit Playground as it appears to a PC
# from https://github.com/todbot/circuitpython-tricks#usb

# This module runs first on boot (before `code.py`).
# sets the name of the Circuit Playground as it appears to a PC
# from https://github.com/todbot/circuitpython-tricks#usb

# Also essentially spamming all the other USB MIDI related names
# to try to ensure your DAW and OS will be able to differentiate
# between different modules.

import storage
import usb_midi
import supervisor

import config


storage.remount("/", readonly=False)
m = storage.getmount("/")
n = config.USB_NAME
m.label = n
usb_midi.set_names(streaming_interface_name = n + "-STR",
				   audio_control_interface_name =n  + "-AUD",
				   in_jack_name = n + "-IN",
				   out_jack_name = n + "-OUT")
supervisor.set_usb_identification(manufacturer = "PERFEC " + n, 
                                  product = n)
storage.remount("/", readonly=True)
